import React from 'react';

export default class Sample extends React.Component {
	render() {
		return (
			<div>
				test
			</div>
		)
	}
}
