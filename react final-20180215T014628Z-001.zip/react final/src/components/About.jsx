import React from 'react';

export default class About extends React.Component {
	render() {
		return (
			<div>
				Hello
			</div>
		)
	}
}
