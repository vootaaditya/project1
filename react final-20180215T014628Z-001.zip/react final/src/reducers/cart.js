const init = {
    data: {}
}
export default(state = init, payload) => {
    switch(payload) {
        case 'add':
        return[...state, payload.item];
        default:
        return state;
    }
}