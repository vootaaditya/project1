import Cart from './cart';
import { combineReducers } from 'redux';

const rootReducers = combineReducers({
    Cart
});

export default rootReducers;