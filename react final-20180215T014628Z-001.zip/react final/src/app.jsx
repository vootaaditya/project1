import React from 'react';
import { connect } from 'react-redux';

import Navigation from './components/Navigation';
import 'normalize.css';
import styles from 'styles/common/button.scss';

 class App extends React.Component {
	render() {
		return (
			<div className='App'>
				<Navigation/>
				<div>
					<h1>It Works!Murali</h1>
					<p>This React project just works including <span className={styles.redBg}>Murali Krishna</span> local styles.</p>
					<p>Enjoy!</p>
				</div>
			</div>
		)
	}
}
function mapStateToProps(state){
	return{
		cart: state.cart
	};
}

export default connect(mapStateToProps)(App)