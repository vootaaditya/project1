# Webpack React Starter Kit

### This repository is no longer maintained. I strongly recommend using [create-react-app](https://github.com/facebookincubator/create-react-app) instead.

## Getting Started

    git clone https://github.com/jkup/webpack-react-starter.git
    cd webpack-react-starter
    npm install
    npm start

Then just open http://localhost:8080 in your browser!
