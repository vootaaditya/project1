import React from 'react';
import Dropdown from './common/dropdown'

import './styles/style.css'

export default class App extends React.Component {

  constructor(props) {
    super(props);

    this.dropDownOnChange = this.dropDownOnChange.bind(this);
    this.handleInput = this.handleInput.bind(this);
    this.handleList = this.handleList.bind(this);
    this.state = {inputValue:"",
      options : [
        {
          "id": "5a3bc1205923488ba81fc0f0",
          "label": "Wilkinson Heath"
        },
        {
          "id": "5a3bc1203a081f417ed12316",
          "label": "Dollie Hooper"
        },
        {
          "id": "5a3bc120baf39c51da1dd224",
          "label": "Morse Reilly"
        },
        {
          "id": "5a3bc12033eb5ec25e29fefe",
          "label": "Erna Raymond"
        },
        {
          "id": "5a3bc120d49012c1fb97b95c",
          "label": "Jocelyn Wheeler"
        },
        {
          "id": "5a3bc1202ee774853515d91c",
          "label": "Jennie Pacheco"
        },
        {
          "id": "5a3bc12022a9c904a16a67f1",
          "label": "Danielle Tyler"
        },
        {
          "id": "5a3bc1207925ac96b7566561",
          "label": "Murray Odonnell"
        },
        {
          "id": "5a3bc120c40336d3bf0f054c",
          "label": "Dillon Pitts"
        },
        {
          "id": "5a3bc12044871010803c8a0f",
          "label": "Gonzales Rasmussen"
        },
        {
          "id": "5a3bc1201646d178e2a9d1fa",
          "label": "Schneider Delaney"
        },
        {
          "id": "5a3bc12033ea728fd8cbedb0",
          "label": "Mosley Cameron"
        }
      ]
    }
  }

  dropDownOnChange (change,obj){
      console.log("Dropdown")
        console.log(obj)
        console.log('onChangeForSelect:\noldValue: ' +
                change.oldValue +
                '\nnewValue: '
                + change.newValue);

    }

  handleInput(e){
      this.setState({inputValue:e})
  }

  handleList(){
    let inputValue = this.state.inputValue;
    let options = this.state.options;
    let obj = {}
    obj.id = inputValue;
    obj.label = inputValue;
    options.push(obj)
  }




  render() {
    return (
      <main>
        <h6>Auto Suggest</h6>
        <section>       
            <Dropdown id='myDropdown'
                  options={this.state.options}
                  labelField='label'
                  valueField='id'
                  onChange={this.dropDownOnChange}
                  handleInput={this.handleInput}/>
            <button type="button" onClick={this.handleList}>Go</button>
        </section>
      </main>
    )
  }
}

React.render(<App />, document.body);
