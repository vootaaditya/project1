var webpack = require('webpack');
var PATH = require('path');
var CopyWebpackPlugin = require("copy-webpack-plugin");
var ExtractTextWebpackPlugin = require("extract-text-webpack-plugin");

module.exports = {
    entry: [
        'webpack/hot/only-dev-server',
        PATH.join(__dirname, "client", "main.js")
    ],
    output: {
        path: PATH.join(__dirname, 'dist'),
        filename: "bundle.js"
    },
    module: {
            loaders: [
      {
        test: /.jsx?$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        query: {
          presets: ['es2015', 'react']
        }
      },
      {
        test: /\.css$/,
        loader: "style-loader!css-loader"
      },
      {
        test: /\.png$/,
        loader: "url-loader?limit=100000"
      },
      {
        test: /\.jpg$/,
        loader: "file-loader"
      },
      {
        test: /\.(woff|woff2)(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'url?limit=10000&mimetype=application/font-woff'
      },
      {
        test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'url?limit=10000&mimetype=application/octet-stream'
      },
      {
        test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'file'
      },
      {
        test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
        loader: 'url?limit=10000&mimetype=image/svg+xml'
      }
    ]

    },
    plugins: [
        new webpack.NoEmitOnErrorsPlugin(),
        new webpack.HotModuleReplacementPlugin(),
        //new ExtractTextWebpackPlugin({filename: PATH.join(__dirname, "dist/styles/bundle.css"), disable: false, allChunks: true}),
        new CopyWebpackPlugin([
            { from: PATH.join(__dirname, "client", "common/styles/styles.css"), to: PATH.join(__dirname, "dist/styles/") }
        ])
    ]
};
