require('babel-core/register')({
    presets: ['es2015']
});
require('./server.js');
