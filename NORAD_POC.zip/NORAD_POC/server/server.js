import express from "express";
import compression from "compression";
import bodyparser from "body-parser";
import https from "https";
import fs from "fs";
import PATH from "path";
import bpConfig from "./helpers/bpConfig.js";


class BrokerPortalApp {
    constructor(bpConfig) {
        this.bpConfig = bpConfig;
        this.config = bpConfig.getSetting;  // short form to read settings from config file
        this.app = express();

        let payloadLimit = this.config("MS_payloadLimit");
        this.standardHeaders = [
            { header: "Vary", value: "Origin" },
            { header: "Access-Control-Allow-Headers", value: "Origin, X-Requested-With, Content-Type, Accept" },
            { header: "X-Frame-Options", value: "SAMEORIGIN" }, // DO NOT ALLOW This app to be loaded from frames
            { header: 'Cache-Control', value: 'private, no-cache, no-store, must-revalidate' },
            { header: 'Expires', value: '-1' },
            { header: 'Pragma', value: 'no-cache' },
            { header: "Access-Control-Allow-Origin", value: this.config("accessingOrigin") }
        ];

        this.app.use(bodyparser.json({ limit: payloadLimit }));
        this.app.use(bodyparser.urlencoded({ limit: payloadLimit }));
        this.app.use(bodyparser.raw({ limit: payloadLimit }));
        this.app.use(compression());

        // setup Headers
        this.app.use((err, req, res, next) => {
            console.log("Global handler:", req.path);
            if (!err)
                next();

            console.log("Global Error Handler: ", err);
        });
        this.app.use(this.attachStandardHeaders.bind(this));
    }

    attachStandardHeaders(req, res, next) {
        this.standardHeaders.forEach((keyVal) => {
            res.header(keyVal.header, keyVal.value);
        })

        next();
    }

    startRouters() {
        this.bpApiRouter = new bpApiRouter(this.bpConfig);
        this.app.use("/apps/ptb/api", this.bpApiRouter.router);
        console.log("Api router on:", this.url + "/api");

        // Setup the static folders for images/stylesheets etc.
        this.app.use("/apps/ptb", express.static(PATH.join(__dirname, "..", this.config("staticFolders"))));

        this.bpPageRouter = new bpPageRouter(this.bpConfig);
        this.app.use("/apps/ptb", this.bpPageRouter.router);
        console.log("Page router on:", this.url + "/apps/ptb");

        //this.logRouter = express.Router();
    }

    start() {
        let serverListner = this.config("runOnHttps") ?
            https.createServer({
                pfx: fs.readFileSync(PATH.resolve(__dirname, 'certs/', this.config("host") + ".pfx")),
                passphrase: this.config("sslPassphrase")
            }, this.app) :
            this.app;

        serverListner.listen(this.config("port"), () => {
            this.url = (this.config("runOnHttps") ? "https" : "http") + "://" + this.config("host") + ':' + this.config("port");
            logo();
            console.log("Server started on ", this.url);
            this.startRouters();
        });
    }

}
let app = new express();
let router = express.Router();
let config = new bpConfig();
let bpApp = new BrokerPortalApp(config);

bpApp.start();
