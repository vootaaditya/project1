var log4js = require('log4js');
var madeConfig = require('./madeConfig.js');
var PATH = require('path');

var loggerFilePath = madeConfig.getSetting("logFilePath") || '/wsapps/apps/madeui-logs/serverlogs.log';

console.log("server logger path ->" + loggerFilePath);
log4js.configure({
    appenders: [
        { type: "console" },
        { type: 'dateFile', filename: loggerFilePath, category: "serverlogs", pattern: "-yyyy-MM-dd", maxLogSize: 10485760 }
    ]
});

var logger = log4js.getLogger('serverlogs');
logger.setLevel(madeConfig.getSetting('logLevel'));

module.exports = logger;
