import React, { Component } from 'react';
import './dropdown.css'

class Dropdown extends Component {
  constructor(props) {
    super(props);

    this.handleChange = this.handleChange.bind(this);
    this.autoSuggest = this.autoSuggest.bind(this);
    this.getSelectedFromProps = this.getSelectedFromProps.bind(this);
    this.getObjByName = this.getObjByName.bind(this);
    this.handleExpand = this.handleExpand.bind(this);

    const selected = this.getSelectedFromProps(props);
    const slectedText = this.getSelectedText(selected);
    this.state = { selected: selected, 
                    options:[], 
                    selectedText: slectedText
                  }
  }

  componentWillReceiveProps(nextProps) {
      const selected = this.getSelectedFromProps(nextProps);
        this.setState({
            selected: selected
        });
    }

  getSelectedText(selected){
    let resultObject = this.getObjByName(selected, this.props.options, this.props.valueField);
    let self = this;
    console.log(resultObject)
    if((resultObject !== undefined) && (resultObject.length !== 0)){
      this.setState({slectedText: resultObject[self.props.labelField]})
    }

  }

  getObjByName(nameKey, myArray, key){
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i][key] === nameKey) {
            return myArray[i];
        }
    }
  }




  getSelectedFromProps(props) {
        let selected;
        if (props.value === null && props.options.length !== 0) {
            selected = props.options[0][props.valueField];
        } else {
            selected = props.value;
        }
        return selected;
    }


  autoSuggest (e)  {
      let inputValue =  e.target.value;
      let self = this;
      if(inputValue === ""){
        this.setState({options: [], selectedText:inputValue})
        return;
      }
      let options = this.props.options;
      if (options.length > 0){
        let list = options.filter(function (item) {
          return item[self.props.labelField].indexOf(inputValue) > -1;
        })
        this.setState({ options: list, selectedText: inputValue })
      }else{
        this.setState({ options: [], selectedText: inputValue })
      }

        if(this.props.handleInput){
          this.props.handleInput(inputValue)
        }
  }

  handleExpand(){
    let options = this.props.options;
    if((this.state.options).length > 0){
      options = [];
    }
    
      this.setState({ options: options })        
    
  }

  handleChange (e)  {
      if (this.props.onChange) {
          const change = {
            oldValue: this.state.selected,
            newValue: e[this.props.valueField]
          }
          this.props.onChange(change,e);
      }
      this.setState({
        selectedValue: e[this.props.valueField],
         selectedText: e[this.props.labelField],
         options:[]
      });
  }



  render() {

    const self = this;
       const options = self.state.options.map(function(option) {
           return (
               <li key={option[self.props.valueField]} onClick={() => self.handleChange(option)} value={option[self.props.valueField]}>
                   {option[self.props.labelField]}
               </li>
           )
       });

    return (
      <div className="autosuggest">
        <div className="carat" onClick={this.handleExpand}></div>
      <input type="text" onChange={this.autoSuggest} value={this.state.selectedText}  />
      <span className="validity" onClick={this.handleExpand}></span>
      <ul id={this.props.id}
                   className='form-control'
                   value={this.state.selected}>
               {options}
      </ul>
      </div>
    );
  }
};

Dropdown.propTypes = {
  id: React.PropTypes.string.isRequired,
  options: React.PropTypes.array.isRequired,
  value: React.PropTypes.oneOfType(
            [
                React.PropTypes.number,
                React.PropTypes.string
            ]
        ),
  valueField: React.PropTypes.string,
  labelField: React.PropTypes.string,
  onChange: React.PropTypes.func
};

Dropdown.defaultProps = {
  value: null,
  valueField: 'value',
  labelField: 'label',
  onChange: null
};


export default Dropdown;
