import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from "react-redux";
import { Router, Route, browserHistory, IndexRoute, Redirect } from "react-router";
import store from "./common/store.js";

import MainComponent from "./main/controller"


/**/require('./common/styles/styles.css'); // This is just to generate bundle.css file


class BpClientApp extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                
                {this.props.children}
                
            </div>
        );
    }
}

ReactDOM.render(<Provider store={store}>
    <Router history={browserHistory}>
        <Route path="/apps/ptb" component={BpClientApp}>
            <Route path="employee" component={MainComponent}></Route>
            <IndexRoute component={MainComponent} />
        </Route>
    </Router>
</Provider>, document.getElementById("app"));

export default BpClientApp;
