import { combineReducers } from "redux";

import mainReducers from './../main/reducers.js';

const combinedReducer = combineReducers({
    mainReducers
});

export default combinedReducer;