import React, {Component} from 'react';
import {connect} from 'react-redux';
import _ from 'lodash';
import {bindActionCreators} from 'redux';


import * as mainActions from './actions';


class MainController extends Component{
    constructor(props){
        super(props);
        this.handleInput = this.handleInput.bind(this);
        this.handleButton = this.handleButton.bind(this);
        this.state = {inputValue:''}
    }

  

    handleInput(e) {
      const val = e.target.value;
      this.setState({ inputValue: val})
    }


    handleButton() {
      const inputValue = this.state.inputValue;
      this.props.actions.fetchAccountNumber(inputValue)
    }


    render(){
        let {accountInfo, optionsList} = this.props;
        return (
			<div>
                <div className="header">
                        <ul className="menu">
                            <li><a href="#">Lease</a></li>
                            <li><a href="#">Asset</a></li>
                            <li><a href="#">Quote</a></li>
                            <li><a href="#">Uility</a></li>
                            <li><a href="#">My Norad</a></li>
                            <li><a href="#">RMKTG</a></li>
                            <li><a href="#">Pink Tools</a></li>
                            <li><a href="#">Switch</a></li>
                        </ul>
                     <div className="search">
                         <label>Account sched</label>
                        <input type="text" onChange={this.handleInput} value={this.state.inputValue} />
                        <input type="button" value="Go" onClick={this.handleButton} />
                        <input type="button" value="Next" />
                     </div>
                 </div>
                 {(Object.keys(accountInfo).length > 0) ?
                 <div className="accountInfo">
                     <ul>
                        <li><span>{accountInfo.company}</span></li>
                        <li><label>Tax Code</label><span>{accountInfo.taxCode}</span></li>
                        <li><label>Cust Name</label><span>{accountInfo.custName}</span></li>
                        <li><label>AMO / EG Owner</label><span>{accountInfo.owner}</span></li>
                        <li><label>PO Type</label><span>{accountInfo.poType}</span></li>
                        <li><label>Contact</label><span>{accountInfo.contact}</span></li>
                        <li><label>Collat Desc</label><span>{accountInfo.collatDesc}</span></li>
                        <li><label>Ext Ref z/Conv Ind</label><span>{accountInfo.ref}</span></li>
                        <li><label>Phone</label><span>{accountInfo.phone}</span></li>
                        <li><label>Program/AssetClass</label><span>{accountInfo.program}</span></li>
                        <li><label>Location</label><span>{accountInfo.location}</span></li>
                        <li><label>Fax</label><span>{accountInfo.fax}</span></li>
                    </ul>
                </div>
                : null}
             </div>
        )
    }
}

function mapStateToProps(state, oldProps){
    return {
        accountInfo: state.mainReducers.accountInfo,
        optionsList: state.mainReducers.optionsList
    }
}

function mapDispatchToProps(dispatch){
    return {
        actions: bindActionCreators(mainActions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(MainController);
