import * as ActionTypes from './actionTypes.js';

const init = {
    accountInfo: {},
    optionsList: []
}

export default function messageReducers(state = init, action) {
    switch (action.type) {
        case ActionTypes.GET_ACCOUNT_DATA_SUCCESS:
            return _.extend({}, state,  {accountInfo:action.payload});
        case ActionTypes.GET_ACCOUNT_DATA_FAIL:
            return _.extend({}, state, { accountInfo: {} });
        case ActionTypes.OPTIONS_LIST:
            let optionsList = state.optionsList;
            optionsList.push(action.payload)
            return _.extend({}, state, { optionsList:optionsList });
        default:
            return state;
    }
}