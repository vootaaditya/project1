import * as ActionTypes from './actionTypes.js';

const data = [
    {
        "company": "ENJOLA",
        "accountNumber": 977942,
        "owner": "Vasquez",
        "taxCode": 5767,
        "custName": "Ruiz",
        "poType": "brown",
        "contact": "+1 (911) 435-3925",
        "collatDesc": "brown",
        "ref": 3585,
        "phone": "+1 (963) 527-2790",
        "program": 977,
        "location": "146.180256",
        "fax": "+1 (910) 583-3423"
    },
    {
        "company": "ORBOID",
        "accountNumber": 277015,
        "owner": "Mariana",
        "taxCode": 4730,
        "custName": "Dean",
        "poType": "green",
        "contact": "+1 (884) 484-2158",
        "collatDesc": "blue",
        "ref": 9274,
        "phone": "+1 (996) 587-3493",
        "program": 849,
        "location": "80.018655",
        "fax": "+1 (816) 442-3030"
    },
    {
        "company": "ILLUMITY",
        "accountNumber": 784363,
        "owner": "Lizzie",
        "taxCode": 9018,
        "custName": "Barbara",
        "poType": "brown",
        "contact": "+1 (924) 463-2486",
        "collatDesc": "green",
        "ref": 6482,
        "phone": "+1 (963) 490-3364",
        "program": 449,
        "location": "43.902569",
        "fax": "+1 (993) 583-2414"
    },
    {
        "company": "NIKUDA",
        "accountNumber": 162117,
        "owner": "Josefa",
        "taxCode": 4037,
        "custName": "Castro",
        "poType": "green",
        "contact": "+1 (986) 423-3813",
        "collatDesc": "green",
        "ref": 5863,
        "phone": "+1 (865) 572-2182",
        "program": 480,
        "location": "-54.131053",
        "fax": "+1 (961) 599-3166"
    },
    {
        "company": "ZERBINA",
        "accountNumber": 377419,
        "owner": "Wynn",
        "taxCode": 5845,
        "custName": "Cobb",
        "poType": "blue",
        "contact": "+1 (987) 475-2721",
        "collatDesc": "green",
        "ref": 3610,
        "phone": "+1 (891) 499-3596",
        "program": 940,
        "location": "-134.319393",
        "fax": "+1 (936) 473-2536"
    },
    {
        "company": "NETPLODE",
        "accountNumber": 246964,
        "owner": "James",
        "taxCode": 2208,
        "custName": "Linda",
        "poType": "brown",
        "contact": "+1 (957) 579-3131",
        "collatDesc": "brown",
        "ref": 9224,
        "phone": "+1 (914) 458-2865",
        "program": 245,
        "location": "-10.435958",
        "fax": "+1 (955) 551-3566"
    },
    {
        "company": "ENTROFLEX",
        "accountNumber": 784736,
        "owner": "Phyllis",
        "taxCode": 3248,
        "custName": "Crawford",
        "poType": "brown",
        "contact": "+1 (872) 444-3504",
        "collatDesc": "green",
        "ref": 9179,
        "phone": "+1 (977) 498-2928",
        "program": 400,
        "location": "-101.237682",
        "fax": "+1 (973) 522-3132"
    },
    {
        "company": "TRI@TRIBALOG",
        "accountNumber": 176151,
        "owner": "Miranda",
        "taxCode": 9627,
        "custName": "Gail",
        "poType": "green",
        "contact": "+1 (997) 499-2208",
        "collatDesc": "green",
        "ref": 2936,
        "phone": "+1 (834) 408-2114",
        "program": 891,
        "location": "148.821535",
        "fax": "+1 (928) 417-2295"
    },
    {
        "company": "BUZZMAKER",
        "accountNumber": 684499,
        "owner": "Carissa",
        "taxCode": 8424,
        "custName": "Gross",
        "poType": "blue",
        "contact": "+1 (966) 519-3287",
        "collatDesc": "green",
        "ref": 4394,
        "phone": "+1 (813) 542-3893",
        "program": 425,
        "location": "67.26973",
        "fax": "+1 (815) 583-3409"
    },
    {
        "company": "INCUBUS",
        "accountNumber": 952291,
        "owner": "Shawna",
        "taxCode": 8979,
        "custName": "Corrine",
        "poType": "blue",
        "contact": "+1 (891) 498-2477",
        "collatDesc": "brown",
        "ref": 3875,
        "phone": "+1 (835) 594-2658",
        "program": 108,
        "location": "-93.083387",
        "fax": "+1 (910) 527-3343"
    },
    {
        "company": "MOBILDATA",
        "accountNumber": 780542,
        "owner": "Oneil",
        "taxCode": 6076,
        "custName": "June",
        "poType": "blue",
        "contact": "+1 (837) 553-3950",
        "collatDesc": "brown",
        "ref": 7807,
        "phone": "+1 (822) 542-3186",
        "program": 700,
        "location": "158.190558",
        "fax": "+1 (995) 476-3003"
    },
    {
        "company": "SEQUITUR",
        "accountNumber": 648321,
        "owner": "Parker",
        "taxCode": 3774,
        "custName": "Munoz",
        "poType": "green",
        "contact": "+1 (873) 403-2776",
        "collatDesc": "blue",
        "ref": 8584,
        "phone": "+1 (960) 439-2358",
        "program": 692,
        "location": "139.031928",
        "fax": "+1 (887) 555-2869"
    },
    {
        "company": "JOVIOLD",
        "accountNumber": 755273,
        "owner": "Winnie",
        "taxCode": 5418,
        "custName": "Shannon",
        "poType": "blue",
        "contact": "+1 (996) 586-3169",
        "collatDesc": "green",
        "ref": 9714,
        "phone": "+1 (930) 588-3200",
        "program": 446,
        "location": "-142.263904",
        "fax": "+1 (869) 460-3628"
    }
]

export function updateComponentState(type, payload){
    return {type, payload};
}

export function fetchAccountNumber(accnumber){
    return (dispatch) => {
        let accountNumber = parseInt(accnumber);
        let obj = data.filter((item) => item.accountNumber === accountNumber);
      console.log(accnumber)
      if(obj.length > 0){
          dispatch(updateComponentState(ActionTypes.GET_ACCOUNT_DATA_SUCCESS, obj[0]));
          dispatch(updateComponentState(ActionTypes.OPTIONS_LIST, {id:accountNumber, label:accountNumber}));
      }else{
          dispatch(updateComponentState(ActionTypes.GET_ACCOUNT_DATA_FAIL, ''));
          alert("Enter Valid Account Number")
      }
        
    }
}
