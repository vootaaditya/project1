import express from 'express';

export default class bpBaseRouter {
    constructor(bpConfig) {
        this.bpConfig = bpConfig;
        this.router = express.Router();
        this.handlers = [];

        this.initializeRoutes();
        this.startRoutes();
    }

    initializeRoutes() {

    }

    startRoutes() {
        // default method - empty - for subclasses to override
        this.handlers.forEach((val, index) => {
            this.router.get(val.path, [this.logRoute, val.handler]);
        })
    }

    router() {
        return this.router;
    }

    logRoute(req, res, next) {
        console.log('log middleware - ', req.path);
        next();
    }
}
