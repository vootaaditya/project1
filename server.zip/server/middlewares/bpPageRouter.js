import express from 'express';
import fs from 'fs';
import PATH from 'path';
import cheerio from 'cheerio';
import bpBaseRouter from './bpBaseRouter.js';

export default class bpPageRouter extends bpBaseRouter {
    constructor(bpConfig) {
        super(bpConfig);
    }

    initializeRoutes() {
        this.handlers.push({ path: '/*', handler: this.rootRouter});
    }

    rootRouter(req, res, next) {
        console.log('Serving App.html....');
        let file = PATH.join(__dirname, "../../dist", "app.html");
        console.log("File: ", file);
        fs.readFile(file, 
            (error, data) => {
                if (error){
                    console.log("Unable to read app.html", error);
                    res.send({error: error});
                } else {
                    console.log("App.html fetched successfully.");
                    res.send(cheerio.load(data.toString()).html());
                }
            });

        //res.send({message: 'Hello World - Page Router'});
    }
}