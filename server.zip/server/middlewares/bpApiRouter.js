import express from "express";
import request from "request";
import reqpromise from "request-promise";
import bodyparser from "body-parser";
import multer from "multer";
import _ from 'lodash';
import PATH from "path";
import Promise from "bluebird";
import { Readable } from 'stream';
import es from 'event-stream';

import bpBaseRouter from "./bpBaseRouter.js";
import mocks from "./../helpers/mocks.js";

export default class bpApiRouter extends bpBaseRouter {
    constructor(bpConfig) {
        super(bpConfig);

        let upload = multer();
        this.router.use(bodyparser.urlencoded({ extended: true }));
        this.router.use(bodyparser.json());
    }

    initializeRoutes() {
        // initialize handlers
        // this is for GET handlers
        this.handlers.push({ path: "/commissions/:paidTin", handler: this.commissionsSummary.bind(this) });
        this.handlers.push({ path: "/commissions/:statementID/details", handler: this.commissionDetails.bind(this) });
        this.handlers.push({ path: "/commissions/:paidTin/:statementDate/:source/:statementID/pdf", handler: this.commissionStatementPdf.bind(this) });
        this.handlers.push({ path: "/user/:userid", handler: this.userProfile.bind(this) });
        this.handlers.push({ path: "/config", handler: this.configHandler.bind(this) });
    }

    commissionsSummary(req, res, next) {
        let paidTin = req.params.paidTin;
        let url = this.bpConfig.getServiceEndpoint("commissionSummary").replace("{paidTin}", paidTin);
        let options = {
            url: url,
            headers: {},
            rejectUnauthorized: false,
            json: true
        }
        reqpromise(options)
            .then((data) => {
               res.json(data);
            })
            .catch((error) => {
                console.log("Error fetching commissions summary of", paidTin, ". Error payload:", error);
                if (_.isUndefined(error.error) || ["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.error.code))
                    res.status(500).json({ error: { code: 500, message: "Unable to fetch commissions summary!!!" } });
                else
                    res.status(502).json({ error: { code: 502, message: error.message } });
            })

        // mocks.sendCommissionsSummary(paidTin, req, res, next)
        //     .then(data => {
        //         res.json(JSON.parse(data.toString()));
        //     })
        //     .catch(error => {
        //        if (["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.code) > -1)
        //             res.status(502).json({ error: { code: 502, message: error.message } });
        //         else if (["ENOENT"].indexOf(error.code) > -1)
        //             res.status(404).json({ error: { code: 404, message: "No commission summary details found!!!" } });
        //     });
    }

    commissionDetails(req, res, next) {
        let statementID = req.params.statementID;
        let url = this.bpConfig.getServiceEndpoint("commissionDetails").replace("{statementID}", statementID);
        let options = {
            url: url,
            headers: {},
            rejectUnauthorized: false,
            json: true
        }
        reqpromise(options)
            .then((data) => {
               res.json(data);
            })
            .catch((error) => {
                console.log("Error fetching commission details of", statementID, ". Error payload:", error);
                if (_.isUndefined(error.error) || ["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.error.code))
                    res.status(500).json({ error: { code: 500, message: "Unable to fetch commission details!!!" } });
                else
                    res.status(502).json({ error: { code: 502, message: error.message } });
            })

        // TODO: date validation required?

        // Throw error if source is not passed i.e. /paidTin/stmtDate/pdf
        // mocks.fetchCommissionDetails(statementID, req, res, next)
        //     .then(data => {
        //         res.json(JSON.parse(data.toString()));
        //     })
        //     .catch(error => {
        //        if (["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.code) > -1)
        //             res.status(502).json({ error: { code: 502, message: error.message } });
        //         else if (["ENOENT"].indexOf(error.code) > -1)
        //             res.status(404).json({ error: { code: 404, message: "No commission summary details found!!!" } });
        //     });
    }

    commissionStatementPdf(req, res, next) {
        let paidTin = req.params.paidTin;
        let statementDate = req.params.statementDate.split("-").join("/");
        let fileNameToSet = "Anthem_{stmtDate}_commissions.pdf"
            .replace("{stmtDate}", req.params.statementDate.split('-').join('').trim());
        let source = req.params.source;
        let statementID = req.params.statementID;

        let url = this.bpConfig.getServiceEndpoint("commissionStatementPdf")
            .replace("{paidTin}", paidTin)
            .replace("{statementDate}", statementDate)
            .replace("{source}", source)
            .replace("{statementID}", statementID);
        console.log(url);
        let options = {
            url: url,
            headers: {},
            rejectUnauthorized: false
        }
        request.get(url)
            .on("error", (error) => {
                console.log("Failed in fetching PDF: ", error);
                if (_.isUndefined(error.error) || ["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.error.code))
                    res.status(500).json({ error: { code: 500, message: "Unable to fetch commissions statement!!!" } });
                else
                    res.status(502).json({ error: { code: 502, message: error.message } });
            })
            .pipe(res); 

        // mocks.fetchCommissionStatementPdf(req.params.stmtId)
        //     .then((data) => {
        //         res.header('Content-Type', 'application/pdf');
        //         res.header('Content-disposition', 'attachment; filename=Anthem_' + new Date().toDateString() + '_commissions.pdf');
        //         res.send(new Buffer(data, 'base64'));
        //     })
        //     .catch(error => {
        //         console.log(req.path, 'failed. Available description:', error);
        //         if (["ETIMEOUT", "ECONNREFUSED", "ENOTFOUND"].indexOf(error.code) > -1)
        //             res.status(502).json({ error: { code: 502, message: error.message } });
        //         else if (["ENOENT"].indexOf(error.code) > -1)
        //             res.status(404).json({ error: { code: 404, message: "No commission statement found!!!" } });
        //     });
    }

    userProfile(req, res, next) {
        let userid = req.params.userid;

        res.json({ message: "UserProfile of /" + userid });
    }

    configHandler(req, res, next) {
        res.json(this.bpConfig.getSetting("clientConfig"));
    }
}
