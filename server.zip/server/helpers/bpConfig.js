import nconf from 'nconf';
import path from 'path';

let ROOT = './..';


// Define configuration Object to be accessible to all middlewareMgmt objects into baseManager
export default class bpConfig {
	constructor() {
		let defaultConfig;
		let environment = nconf.argv().get("environment") || 'LOCAL';
		let port = nconf.argv().get("port") || '7071';
		let host = nconf.argv().get("host") || 'localhost';

		environment = environment.toUpperCase();
		defaultConfig = path.resolve(__dirname, ROOT, 'config/' + environment + '.json');
		nconf.argv().env().file({ file: defaultConfig }).defaults({ ENV: 'development' });

		nconf.set('environment', environment);
		nconf.set('port', port);
		nconf.set('host', host);

        this.getSetting = this.getSetting.bind(this);
	}

	// Returns server configuration
	getSetting(setting) {
		return nconf.get(setting);
	}

	getServicesSetting() {
		return nconf.get("endPoints")["services"];
	}

	getContentServicesSetting() {
		return nconf.get("endPoints")["contentServices"];
	}

	getPtbServicesSetting() {
		return nconf.get("endPoints")["ptbServices"];
	}

	getToggles() {
		return (nconf.get("featureToggles") || {});
	}

	isFeatureEnabled(setting) {
		return this.getToggles()[setting] || false;
	}

	getServiceEndpoint(serviceKey) {
		return this.getServicesSetting()[serviceKey];
	}

	getContentServiceEndpoint(serviceKey) {
		return this.getContentServicesSetting()[serviceKey]
	}

	getPtbServiceEndpoint(serviceKey) {
		return this.getPtbServicesSetting()[serviceKey]
	}
}
