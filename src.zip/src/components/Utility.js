import React from 'react';

 var Utility = (props)=>{
   return (
     <div>
      <table>
        <tr>
          <td> Current Payment</td>
          <td> Us $764.83</td>
        </tr>
        <tr>
          <td>Monthly Amount</td>
          <td>$0.00</td>
        </tr>
        <tr>
         <td>Security Deposit</td>
         <td>$20,000.00</td>
        </tr>
      </table>
     </div>
   );
 }
 
 export default Utility;