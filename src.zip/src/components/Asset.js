import React from 'react';

 var Asset = (props)=>{
   return (
     <div>
      <table>
        <tr>
          <td> AutoInfo</td>
          <td>Issued</td>
        </tr>
        <tr>
          <td>GPO Amt</td>
          <td>$0.00</td>
        </tr>
        <tr>
         <td>Net Book Value</td>
         <td>$30,000.00</td>
        </tr>
      </table>
     </div>
   );
 }
 
 export default Asset;