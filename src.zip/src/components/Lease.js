import React from 'react';

 var Lease = (props)=>{
   return (
     <div>
      <table>
        <tr>
          <td> Status Code</td>
          <td>9- Disposed</td>
        </tr>
        <tr>
          <td>EG Indicator</td>
          <td>N</td>
        </tr>
        <tr>
         <td>OEC</td>
         <td>$20,000.00</td>
        </tr>
      </table>
     </div>
   );
 }
 
 export default Lease;