import React, { Component } from 'react';
import Lease from './components/Lease';
import  Asset from './components/Asset';
import Utility  from './components/Utility';

class App extends Component{
  constructor(props){
    super(props);
    this.state={lease:false,asset:false,utility:false};
    this.showLeaseDetails = this.showLeaseDetails.bind(this);
    this.showAssetDetaails = this.showAssetDetaails.bind(this);
    this.showUtilityDetails = this.showUtilityDetails.bind(this);
  }
  showLeaseDetails(){
    this.setState({...this.state,lease:true,asset:false,utility:false});
  }
  showAssetDetaails(){
    this.setState({...this.state,lease:false,asset:true,utility:false});
  }
  showUtilityDetails(){
    this.setState({...this.state,lease:false,asset:false,utility:true});
  }
  render(){
    return(

        <div>
          <input type="button" value ="Lease" onClick={this.showLeaseDetails}></input>
          <input type="button" value ="Asset" onClick={this.showAssetDetaails}></input>
          <input type="button" value ="Utility" onClick={this.showUtilityDetails}></input>

            {this.state.lease === false?null:<Lease />}
            {this.state.asset === false?null:<Asset />}
            {this.state.utility === false?null:<Utility />}
        </div>
    );
  }
}

export default App;
